const express = require("express");
const bcrypt = require("bcrypt");
const nodemailer = require("nodemailer");

const Employee = require("../models/Employee");
const auth = require("../middleware/auth");

const router = express.Router();

// Email configuration
const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    }
});

// Generate Employee ID
async function generateEmpId() {
    const lastEmployee = await Employee.findOne()
        .sort({ createdAt: -1 });

    if (!lastEmployee) {
        return "EMP1001";
    }

    const lastNumber = parseInt(
        lastEmployee.empid.replace("EMP", "")
    );

    return "EMP" + (lastNumber + 1);
}

// Generate random password
function generatePassword() {
    return Math.random()
        .toString(36)
        .slice(-8);
}


// Employee list
router.get("/employees", auth, async (req, res) => {
    try {
        const employees = await Employee.find()
            .sort({ createdAt: -1 });

        res.render("employees/index", {
            employees
        });

    } catch (error) {
        res.status(500).send(error.message);
    }
});


// Add employee page
router.get("/employees/add", auth, async (req, res) => {
    res.render("employees/add");
});


// Insert employee
router.post("/employees/add", auth, async (req, res) => {
    try {
        const {
            name,
            email,
            department,
            designation,
            basicSalary
        } = req.body;

        const empid = await generateEmpId();

        // Generate temporary password
        const plainPassword = generatePassword();

        // Salary calculation
        const basic = Number(basicSalary);

        const hra = basic * 0.20;
        const da = basic * 0.10;
        const grossSalary = basic + hra + da;

        // Encrypt password
        const hashedPassword = await bcrypt.hash(
            plainPassword,
            10
        );

        const employee = new Employee({
            empid,
            name,
            email,
            department,
            designation,
            basicSalary: basic,
            hra,
            da,
            grossSalary,
            password: hashedPassword
        });

        await employee.save();

        // Send employee email
        await transporter.sendMail({
            from: process.env.EMAIL_USER,
            to: email,
            subject: "ERP Employee Account Created",
            html: `
                <h2>Welcome to the ERP System</h2>

                <p>Hello ${name},</p>

                <p>Your employee account has been created.</p>

                <p><b>Employee ID:</b> ${empid}</p>
                <p><b>Temporary Password:</b> ${plainPassword}</p>

                <p>
                    Please change your password after your first login.
                </p>

                <hr>

                <p>
                    Regards,<br>
                    ERP Administration
                </p>
            `
        });

        res.redirect("/employees");

    } catch (error) {
        console.error(error);
        res.status(500).send(error.message);
    }
});


// Edit employee page
router.get("/employees/edit/:id", auth, async (req, res) => {
    try {
        const employee = await Employee.findById(req.params.id);

        if (!employee) {
            return res.status(404).send("Employee not found");
        }

        res.render("employees/edit", {
            employee
        });

    } catch (error) {
        res.status(500).send(error.message);
    }
});


// Update employee
router.post("/employees/edit/:id", auth, async (req, res) => {
    try {
        const {
            name,
            email,
            department,
            designation,
            basicSalary
        } = req.body;

        const basic = Number(basicSalary);

        const hra = basic * 0.20;
        const da = basic * 0.10;
        const grossSalary = basic + hra + da;

        await Employee.findByIdAndUpdate(
            req.params.id,
            {
                name,
                email,
                department,
                designation,
                basicSalary: basic,
                hra,
                da,
                grossSalary
            }
        );

        res.redirect("/employees");

    } catch (error) {
        res.status(500).send(error.message);
    }
});


// Delete employee
router.post("/employees/delete/:id", auth, async (req, res) => {
    try {
        await Employee.findByIdAndDelete(req.params.id);

        res.redirect("/employees");

    } catch (error) {
        res.status(500).send(error.message);
    }
});


module.exports = router;