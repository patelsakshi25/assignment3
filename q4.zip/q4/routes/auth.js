const express = require("express");
const bcrypt = require("bcrypt");
const Admin = require("../models/Admin");

const router = express.Router();

// Login page
router.get("/login", (req, res) => {
    res.render("login", {
        error: null
    });
});

// Login
router.post("/login", async (req, res) => {
    try {
        const { username, password } = req.body;

        const admin = await Admin.findOne({ username });

        if (!admin) {
            return res.render("login", {
                error: "Invalid username or password"
            });
        }

        const validPassword = await bcrypt.compare(
            password,
            admin.password
        );

        if (!validPassword) {
            return res.render("login", {
                error: "Invalid username or password"
            });
        }

        req.session.adminId = admin._id;
        req.session.username = admin.username;

        res.redirect("/dashboard");

    } catch (error) {
        console.error(error);

        res.render("login", {
            error: "Something went wrong"
        });
    }
});

// Logout
router.get("/logout", (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.send("Unable to logout");
        }

        res.clearCookie("connect.sid");
        res.redirect("/login");
    });
});

module.exports = router;