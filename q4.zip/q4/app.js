require("dotenv").config();

const express = require("express");
const mongoose = require("mongoose");
const session = require("express-session");

const authRoutes = require("./routes/auth");
const employeeRoutes = require("./routes/employee");

const app = express();


// MongoDB connection
mongoose.connect(process.env.MONGO_URI)
    .then(() => {
        console.log("MongoDB connected");
    })
    .catch((error) => {
        console.log("MongoDB connection error:", error);
    });


// EJS
app.set("view engine", "ejs");


// Middleware
app.use(express.urlencoded({
    extended: true
}));

app.use(express.json());

app.use(
    session({
        secret: process.env.SESSION_SECRET,
        resave: false,
        saveUninitialized: false,
        cookie: {
            maxAge: 1000 * 60 * 60,
            httpOnly: true
        }
    })
);


// Routes
app.use("/", authRoutes);
app.use("/", employeeRoutes);


// Dashboard
app.get("/dashboard", (req, res) => {

    if (!req.session.adminId) {
        return res.redirect("/login");
    }

    res.render("dashboard", {
        username: req.session.username
    });
});


// Home
app.get("/", (req, res) => {
    res.redirect("/login");
});


// Start server
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});