const express = require("express");
const path = require("path");
const multer = require("multer");
const fs = require("fs");

const {
    body,
    validationResult
} = require("express-validator");

const app = express();
const PORT = 3000;

// --------------------------------------------------
// Middleware
// --------------------------------------------------

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(express.urlencoded({ extended: true }));

// Make uploaded files accessible from browser
app.use("/uploads", express.static(path.join(__dirname, "public/uploads")));

// --------------------------------------------------
// Create upload directory if it doesn't exist
// --------------------------------------------------

const uploadDir = path.join(__dirname, "public/uploads");

if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

// --------------------------------------------------
// Multer configuration
// --------------------------------------------------

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadDir);
    },

    filename: function (req, file, cb) {
        const uniqueName =
            Date.now() +
            "-" +
            Math.round(Math.random() * 1E9) +
            path.extname(file.originalname);

        cb(null, uniqueName);
    }
});

// Allowed image types
const allowedTypes = [
    "image/jpeg",
    "image/png",
    "image/jpg",
    "image/gif",
    "image/webp"
];

const fileFilter = function (req, file, cb) {

    if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(new Error("Only JPG, JPEG, PNG, GIF and WEBP images are allowed."));
    }
};

const upload = multer({
    storage: storage,
    fileFilter: fileFilter,

    limits: {
        fileSize: 2 * 1024 * 1024, // 2 MB per file
        files: 6
    }
});

// --------------------------------------------------
// GET Registration Form
// --------------------------------------------------

app.get("/", (req, res) => {

    res.render("form", {
        errors: [],
        old: {},
        fileError: null
    });

});

// --------------------------------------------------
// POST Registration
// --------------------------------------------------

app.post(
    "/register",

    upload.fields([
        {
            name: "profilePic",
            maxCount: 1
        },
        {
            name: "otherPics",
            maxCount: 5
        }
    ]),

    [

        // Username
        body("username")
            .trim()
            .notEmpty()
            .withMessage("Username is required.")
            .isLength({ min: 3, max: 20 })
            .withMessage("Username must be 3 to 20 characters.")
            .matches(/^[a-zA-Z0-9_]+$/)
            .withMessage("Username can contain only letters, numbers and underscore."),

        // Password
        body("password")
            .notEmpty()
            .withMessage("Password is required.")
            .isLength({ min: 6 })
            .withMessage("Password must be at least 6 characters long."),

        // Confirm Password
        body("confirmPassword")
            .notEmpty()
            .withMessage("Confirm password is required.")
            .custom((value, { req }) => {
                if (value !== req.body.password) {
                    throw new Error("Passwords do not match.");
                }

                return true;
            }),

        // Email
        body("email")
            .trim()
            .notEmpty()
            .withMessage("Email is required.")
            .isEmail()
            .withMessage("Please enter a valid email address."),

        // Gender
        body("gender")
            .notEmpty()
            .withMessage("Please select gender.")
            .isIn(["Male", "Female", "Other"])
            .withMessage("Invalid gender selected."),

        // Hobbies
        body("hobbies")
            .optional()
            .isArray()
            .withMessage("Invalid hobbies.")
    ],

    (req, res) => {

        const errors = validationResult(req);

        // --------------------------------------------------
        // If validation fails
        // --------------------------------------------------

        if (!errors.isEmpty()) {

            return res.render("form", {
                errors: errors.array(),
                old: req.body,
                fileError: null
            });

        }

        // --------------------------------------------------
        // File validation
        // --------------------------------------------------

        const profilePic =
            req.files && req.files.profilePic
                ? req.files.profilePic[0]
                : null;

        const otherPics =
            req.files && req.files.otherPics
                ? req.files.otherPics
                : [];

        if (!profilePic) {

            return res.render("form", {
                errors: [
                    {
                        msg: "Profile picture is required."
                    }
                ],
                old: req.body,
                fileError: null
            });

        }

        // --------------------------------------------------
        // Display result
        // --------------------------------------------------

        res.render("result", {

            user: {
                username: req.body.username,
                email: req.body.email,
                gender: req.body.gender,
                hobbies: req.body.hobbies || [],
                profilePic: profilePic,
                otherPics: otherPics
            }

        });

    }
);

// --------------------------------------------------
// Download uploaded file
// --------------------------------------------------

app.get("/download/:filename", (req, res) => {

    const filename = path.basename(req.params.filename);

    const filePath = path.join(uploadDir, filename);

    if (!fs.existsSync(filePath)) {
        return res.status(404).send("File not found.");
    }

    res.download(filePath, filename, (err) => {

        if (err) {
            console.log(err);
        }

    });

});

// --------------------------------------------------
// Multer error handler
// --------------------------------------------------

app.use((err, req, res, next) => {

    if (err instanceof multer.MulterError) {

        return res.render("form", {
            errors: [],
            old: req.body || {},
            fileError: err.message
        });

    }

    if (err) {

        return res.render("form", {
            errors: [],
            old: req.body || {},
            fileError: err.message
        });

    }

    next();

});

// --------------------------------------------------
// Start server
// --------------------------------------------------

app.listen(PORT, () => {

    console.log(`Server running at http://localhost:${PORT}`);

});
