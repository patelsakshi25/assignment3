const express = require("express");
const session = require("express-session");
const FileStore = require("session-file-store")(session);

const app = express();
const PORT = 3000;

app.use(express.urlencoded({ extended: true }));

app.use(
  session({
    store: new FileStore({
      path: "./sessions"
    }),
    secret: "my-secret-key",
    resave: false,
    saveUninitialized: false,
    cookie: {
      maxAge: 1000 * 60 * 30 // 30 minutes
    }
  })
);

// Login page
app.get("/login", (req, res) => {
  res.send(`
    <h1>Login</h1>

    <form method="POST" action="/login">
      <label>Username:</label>
      <input type="text" name="username" required />

      <br><br>

      <label>Password:</label>
      <input type="password" name="password" required />

      <br><br>

      <button type="submit">Login</button>
    </form>
  `);
});

// Login
app.post("/login", (req, res) => {
  const { username, password } = req.body;

  if (username === "sakshi" && password === "1234") {
    req.session.user = {
      username: username
    };

    return res.redirect("/dashboard");
  }

  res.send("Invalid username or password. <a href='/login'>Try again</a>");
});

// Authentication middleware
function isAuthenticated(req, res, next) {
  if (req.session.user) {
    return next();
  }

  res.redirect("/login");
}

// Protected Route 1
app.get("/dashboard", isAuthenticated, (req, res) => {
  res.send(`
    <h1>Dashboard</h1>
    <p>Welcome, ${req.session.user.username}!</p>

    <a href="/profile">Profile</a><br>
    <a href="/logout">Logout</a>
  `);
});

// Protected Route 2
app.get("/profile", isAuthenticated, (req, res) => {
  res.send(`
    <h1>Profile</h1>
    <p>Username: ${req.session.user.username}</p>

    <a href="/dashboard">Dashboard</a><br>
    <a href="/logout">Logout</a>
  `);
});

// Logout
app.get("/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).send("Could not log out.");
    }

    res.redirect("/login");
  });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});