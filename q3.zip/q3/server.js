require("dotenv").config();

const express = require("express");
const session = require("express-session");
const { RedisStore } = require("connect-redis");
const { createClient } = require("redis");

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Redis client
const redisClient = createClient({
  url: process.env.REDIS_URL,
});

redisClient.on("error", (err) => {
  console.error("Redis Error:", err);
});

// Connect to Redis
async function startServer() {
  await redisClient.connect();

  // Session configuration
  app.use(
    session({
      store: new RedisStore({
        client: redisClient,
        prefix: "myapp:",
      }),
      secret: process.env.SESSION_SECRET,
      resave: false,
      saveUninitialized: false,
      cookie: {
        httpOnly: true,
        secure: false, // true when using HTTPS
        maxAge: 1000 * 60 * 60, // 1 hour
      },
    })
  );

  // -----------------------------
  // Login
  // -----------------------------
  app.post("/login", (req, res) => {
    const { username, password } = req.body;

    // Demo credentials
    if (username !== "admin" || password !== "12345") {
      return res.status(401).json({
        message: "Invalid username or password",
      });
    }

    req.session.user = {
      id: 1,
      username,
    };

    res.json({
      message: "Login successful",
    });
  });

  // -----------------------------
  // Authentication middleware
  // -----------------------------
  function isAuthenticated(req, res, next) {
    if (!req.session.user) {
      return res.status(401).json({
        message: "Unauthorized. Please login first.",
      });
    }

    next();
  }

  // -----------------------------
  // Protected Route 1
  // -----------------------------
  app.get("/profile", isAuthenticated, (req, res) => {
    res.json({
      message: "Welcome to your profile",
      user: req.session.user,
    });
  });

  // -----------------------------
  // Protected Route 2
  // -----------------------------
  app.get("/dashboard", isAuthenticated, (req, res) => {
    res.json({
      message: "Welcome to the dashboard",
      user: req.session.user,
    });
  });

  // -----------------------------
  // Logout
  // -----------------------------
  app.post("/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({
          message: "Logout failed",
        });
      }

      res.clearCookie("connect.sid");

      res.json({
        message: "Logout successful",
      });
    });
  });

  // -----------------------------
  // Start server
  // -----------------------------
  const PORT = process.env.PORT || 3000;

  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});